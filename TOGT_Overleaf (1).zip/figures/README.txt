figures/ (put your PDF/PNG figures here)
In main.tex, add: \includegraphics[width=\linewidth]{figures/your_figure}
